# CodeOrbit Tech - ML Internship | Task 1: Data Preprocessing & EDA
# Dataset: Wine Recognition Dataset (UCI Machine Learning Repository)
import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.datasets import load_wine

wine = load_wine(as_frame=True)
df = wine.frame.rename(columns={"target": "wine_class"})
print("Shape:", df.shape)
print(df.head(), "\n")

# ---------- 1. CLEANING ----------
print("Missing values per column:\n", df.isnull().sum().sum(), "total missing")
df = df.fillna(df.median(numeric_only=True))            # median imputation (no-op if none)
dups = df.duplicated().sum(); print("Duplicate rows:", dups)
df = df.drop_duplicates()

feature_cols = [c for c in df.columns if c != "wine_class"]
Q1, Q3 = df[feature_cols].quantile(0.25), df[feature_cols].quantile(0.75)
IQR = Q3 - Q1
outlier_mask = (df[feature_cols] < Q1 - 1.5*IQR) | (df[feature_cols] > Q3 + 1.5*IQR)
print("\nOutliers per column (IQR rule):\n", outlier_mask.sum()[outlier_mask.sum() > 0])
# Handle outliers by capping (winsorizing) rather than deleting rows (dataset is small)
df[feature_cols] = df[feature_cols].clip(Q1 - 1.5*IQR, Q3 + 1.5*IQR, axis=1)
print("Outliers remaining after capping:",
      ((df[feature_cols] < Q1 - 1.5*IQR) | (df[feature_cols] > Q3 + 1.5*IQR)).sum().sum())
print("Clean shape:", df.shape)

# ---------- 2. SUMMARY STATISTICS ----------
print("\nSummary statistics:\n", df.describe().T.round(2))
print("\nClass distribution:\n", df["wine_class"].value_counts())

# ---------- 3. VISUALISATIONS ----------
df[feature_cols].hist(bins=20, figsize=(14, 10), color="teal"); plt.suptitle("Feature distributions")
plt.tight_layout(); plt.savefig("task1_eda/histograms.png", dpi=110); plt.close()

plt.figure(figsize=(11, 8)); sns.heatmap(df.corr(), cmap="coolwarm", center=0)
plt.title("Correlation heatmap"); plt.tight_layout(); plt.savefig("task1_eda/correlation_heatmap.png", dpi=110); plt.close()

plt.figure(figsize=(7, 5)); sns.boxplot(x="wine_class", y="alcohol", data=df)
plt.title("Alcohol by wine class"); plt.savefig("task1_eda/boxplot_alcohol.png", dpi=110); plt.close()

print("\nTop correlations with wine_class:\n", df.corr()["wine_class"].drop("wine_class").abs().sort_values(ascending=False).head(5).round(3))
