# CodeOrbit Machine Learning Internship – Submission

Tasks completed: 3 of 3 (minimum required: 2)

| Task | Dataset (UCI) | Script | Key result |
|---|---|---|---|
| 1. Preprocessing & EDA | Wine Recognition (178 rows, 13 features) | task1_eda/task1_eda.py | No missing values/duplicates; 21 outlier values capped via IQR; flavanoids, OD280/OD315 and total phenols most correlated with wine class |
| 2. Classification | Breast Cancer Wisconsin (569 rows, 30 features) | task2_classification/task2_classification.py | Logistic Regression: Accuracy 98.25%, Precision 98.61%, Recall 98.61% (Decision Tree: 93.86% / 95.77% / 94.44%) |
| 3. Regression | Diabetes (442 rows, 10 features) | task3_regression/task3_regression.py | Linear Regression: R2 = 0.453, RMSE = 53.85 (Polynomial deg-2 + Ridge: R2 = 0.420) |

## How to run
pip install pandas numpy matplotlib seaborn scikit-learn
python task1_eda/task1_eda.py   (same for task2 / task3)

## Insights
- Task 1: Data was already clean; outliers (malic acid, ash, magnesium, colour intensity etc.) were capped, not deleted, because the dataset is small. Wine classes are separable mainly by flavanoids and proline.
- Task 2: Features were standardised before fitting. Logistic Regression beat a depth-4 Decision Tree, with only 2 errors out of 114 test samples. In a medical setting, recall on the malignant class matters most, since a missed malignant case is the costly error.
- Task 3: Diabetes progression is only moderately predictable from these 10 features (R2 ~0.45). The simpler linear model generalised better than the polynomial one, so extra complexity did not help.
