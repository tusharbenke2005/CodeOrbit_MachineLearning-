# CodeOrbit Tech - ML Internship | Task 3: Regression Model for Prediction
# Dataset: Diabetes dataset (disease progression after one year) - scikit-learn / Efron et al.
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

data = load_diabetes(as_frame=True)
X, y = data.data, data.target
print("Shape:", X.shape, "| Missing:", X.isnull().sum().sum())
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

lin = LinearRegression().fit(X_train, y_train)
poly = make_pipeline(PolynomialFeatures(2), Ridge(alpha=1.0)).fit(X_train, y_train)  # polynomial (deg 2) + Ridge to limit overfitting

def report(name, model):
    p = model.predict(X_test)
    print(f"{name:28s} MAE={mean_absolute_error(y_test,p):7.2f}  RMSE={np.sqrt(mean_squared_error(y_test,p)):7.2f}  R2={r2_score(y_test,p):.4f}")
    return p
print("\nModel performance on test set:")
p_lin = report("Linear Regression", lin)
p_poly = report("Polynomial (deg 2) + Ridge", poly)

print("\nLinear regression coefficients:\n", pd.Series(lin.coef_, index=X.columns).sort_values(key=abs, ascending=False).round(1))

fig, axes = plt.subplots(1, 2, figsize=(11, 5))
for ax, p, t in zip(axes, [p_lin, p_poly], ["Linear Regression", "Polynomial Regression"]):
    ax.scatter(y_test, p, alpha=0.7, color="teal")
    ax.plot([y.min(), y.max()], [y.min(), y.max()], "r--", label="Perfect prediction")
    ax.set_xlabel("Actual"); ax.set_ylabel("Predicted"); ax.set_title(t); ax.legend()
plt.tight_layout(); plt.savefig("task3_regression/actual_vs_predicted.png", dpi=110)
