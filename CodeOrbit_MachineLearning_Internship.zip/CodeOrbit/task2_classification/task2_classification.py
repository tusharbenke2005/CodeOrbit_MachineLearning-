# CodeOrbit Tech - ML Internship | Task 2: Simple Classification Model
# Dataset: Breast Cancer Wisconsin (Diagnostic) - UCI repository
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix, ConfusionMatrixDisplay, classification_report

data = load_breast_cancer()
X, y = data.data, data.target           # 0 = malignant, 1 = benign
print("Samples:", X.shape[0], "| Features:", X.shape[1], "| Classes:", {str(n): int(c) for n, c in zip(data.target_names, np.bincount(y))})

# Train / test split (80/20, stratified)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler().fit(X_train)
X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)
print("Train:", X_train.shape, "Test:", X_test.shape)

models = {"Logistic Regression": LogisticRegression(max_iter=1000),
          "Decision Tree": DecisionTreeClassifier(max_depth=4, random_state=42)}
results = {}
for name, m in models.items():
    m.fit(X_train_s, y_train); pred = m.predict(X_test_s)
    results[name] = (m, pred)
    print(f"\n=== {name} ===")
    print(f"Accuracy : {accuracy_score(y_test, pred):.4f}")
    print(f"Precision: {precision_score(y_test, pred):.4f}")
    print(f"Recall   : {recall_score(y_test, pred):.4f}")
    print("Confusion matrix:\n", confusion_matrix(y_test, pred))

print("\nClassification report (Logistic Regression):\n",
      classification_report(y_test, results["Logistic Regression"][1], target_names=data.target_names))

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
for ax, (name, (m, pred)) in zip(axes, results.items()):
    ConfusionMatrixDisplay(confusion_matrix(y_test, pred), display_labels=data.target_names).plot(ax=ax, colorbar=False)
    ax.set_title(name)
plt.tight_layout(); plt.savefig("task2_classification/confusion_matrices.png", dpi=110)
